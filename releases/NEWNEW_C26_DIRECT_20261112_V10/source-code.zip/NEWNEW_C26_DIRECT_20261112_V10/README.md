# NEWNEW C26 V10 独立工程

最新代码版本：NEWNEW_C26_DIRECT_20261112_V10。

Keil打开[demo/mdk/newnew_c26.uvprojx](demo/mdk/newnew_c26.uvprojx)，目标nor_sdram_zf_dtcm；所有本工程libraries与demo相对路径一并保留。C26 ON发车、OFF停车。直道1.4m/s，明显弯道降速；实际环岛最高1.0m/s，避砖0.55m/s。

[交接文档](https://github.com/ljpppseu-boop/ljppp/blob/main/docs/changes/2026-11-12_NEWNEW_C26_V10_HANDOFF.md) · [冻结固件与源码包](https://github.com/ljpppseu-boop/ljppp/tree/main/releases/NEWNEW_C26_DIRECT_20261112_V10)。

Keil构建0错误0警告、所列Host检查通过；V10尚未实车验收。不同MPC/NEWNEW构型不可混用板载身份与参数。第三方源码头与SDK原文件保留；本轮未重新声明第三方许可证。原始视频/串口录制本地保留，仅发布选定结构化证据。
